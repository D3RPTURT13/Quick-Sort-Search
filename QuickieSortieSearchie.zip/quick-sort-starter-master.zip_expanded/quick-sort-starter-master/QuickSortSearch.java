
public class QuickSortSearch {
public static int binarySearch(int[] arr, int lo, int hi, int x){
	if (lo <= hi) {
		int mid;
		mid = lo + (hi - 1) / 2;
		if (x == arr[mid]) {
			return mid;
		} else if (x < arr[mid]) {
			return binarySearch(arr, lo, mid - 1, x);
		} else {
			return binarySearch(arr, mid + 1, hi, x);
		} 
	} else {
		return - 1;
	}
}
}

