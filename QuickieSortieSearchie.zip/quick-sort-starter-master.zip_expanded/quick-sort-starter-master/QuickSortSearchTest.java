import static org.junit.Assert.*;

import org.junit.Test;

public class QuickSortSearchTest {

	@Test
	public void testBinarySearch() {
		int[] test1 = {13, 2, 7, 12, 15, 4, 11, 6, 10, 9, 3, 1, 14, 5, 8};
		QuickSorter.quickSort(test1, 0, 14);
		assertEquals(0, QuickSortSearch.binarySearch(test1,  0,  14,  1));
		assertEquals(4, QuickSortSearch.binarySearch(test1,  0,  14,  5));
		assertEquals(5, QuickSortSearch.binarySearch(test1,  0,  14,  6));
		
	}

}
