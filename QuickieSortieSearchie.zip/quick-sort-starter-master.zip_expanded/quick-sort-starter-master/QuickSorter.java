
public class QuickSorter {
	
	private int array[];
    private int length;
 
    public void sort(int[] inputArr) {
         //like the title says
        if (inputArr == null || inputArr.length == 0) {
            return;
        }
        this.array = inputArr;
        length = inputArr.length;
        quickSort(array, 0, length - 1);
    }
 
    public static void quickSort(int[] array, int lo, int hi) {
        ///the main quick sort stuffs.....and nothing more 
        int i = lo;
        int j = hi;
       
        int pivot = array[lo+(hi-lo)/2];
       
        while (i <= j) {
           
            while (array[i] < pivot) {
                i++;
            }
            while (array[j] > pivot) {
                j--;
            }
            if (i <= j) {
                exchangeNumbers(array, i, j);
                i++;
                j--;
            }
        }
        if (lo < j)
            quickSort(array, lo, j);
        if (i < hi)
            quickSort(array, i, hi);
    }
 
    public static void exchangeNumbers(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    }
//done, YAYYYY!
