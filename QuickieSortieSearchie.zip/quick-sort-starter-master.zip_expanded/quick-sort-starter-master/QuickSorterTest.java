import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class QuickSorterTest {

	@Test
	public void testquickSort() {
		int[] test1 =  {2, 0, 5, 3, 10};
		int[] ans1 = {0, 2, 3, 5, 10};
		QuickSorter.quickSort(test1, 0, 4);
		assertTrue(Arrays.equals(test1, ans1));
		int[] test2 =  {1, 20, 8, 9, 33};
		int[] ans2 = {1, 8, 9, 20, 33};
		QuickSorter.quickSort(test2, 0, 4);
		assertTrue(Arrays.equals(test2, ans2));
		int[] test3 =  {5, 90, 53, 3, 0};
		int[] ans3 = {0, 3, 5, 53, 90};
		QuickSorter.quickSort(test3, 0, 4);
		assertTrue(Arrays.equals(test3, ans3));
	}

}
